package com.company;

public class Shelter {
    String name;
    String address;

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public Shelter(String name, String address) {
        this.name = name;
        this.address = address;
    }
}
